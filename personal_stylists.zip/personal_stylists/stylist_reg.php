<?php
include('header.php');
?>
	<br><br><br>
   <div id="page-content">
	<br>	<br>	<br>
    	<!--Page Title-->
    	<div class="page section-header text-center">
			<div class="page-title">
        		<div class="wrapper"><h1 class="page-width" style="font-weight:bold">Stylist Registration</h1></div>
      		</div>
		</div>

  <div class="container">
            <div class="row">
            	<div class="col-12 col-sm-12 col-md-8 col-lg-8 mb-4">


       	<center>
        <form action="stylist_reg.php" method="post" enctype="multipart/form-data">
         
              
              <table border="0">
                <tr>
                    <th>NAME</th>
                    <td><input type="text" name="name" value="" pattern="[a-z]{3,}" required ></td>
                
                
                </tr>
                
                <tr>
                    <th>MAIL ID</th>
                    <td><input type="email" name="email" value="" required></td>
                
                
                </tr>
                
                <tr>
                    <th>GENDER</th>
                    <td><input type="radio" name="gender" value="male" checked>male</td>
                    <td><input type="radio" name="gender" value="female">female</td>
                
                
                </tr>

                <tr>
                    <th>MOBILE NUMBER</th>
                    <td><input type="text" name="mobno" value="" pattern="[56789][0-9]{9}" required></td>
                
                
                </tr>

                <tr>
                    <th>ADDRESS</th>
                    <td><textarea cols="60" rows="5" name="address" value="" required></textarea></td>
                
                
                </tr>

                <tr>
                    <th>LOCATION</th>
                    <td><input type="text" name="loc" value="" required></td>
                
                
                </tr>
				
				
				<tr>
                    <th>TRANSACTION ID</th>
                    <td><input type="number" name="transaction_id" value="" required></td>
                
                
                </tr>

                <tr>
                    <th>PASSWORD</th>
                    <td><input type="password" name="pass" value="" id="password1" required></td>
                
                
                </tr>
                <tr>
                    <th>CONFIRM PASSWORD</th>
                    <td><input type="password" name="pass1" value="" id="password2" required></td>
                
                
                </tr>
                <tr>
                    <th>UPLOAD CERTIFICATE</th>
                    <td><input type="file" name="certificate" value="" required></td>
                
                
                </tr>


                
                <tr>
                    
                    <td colspan="2"><center><input type="submit" name="SUBMIT" value="SUBMIT"></td></center>
                
                
                </tr>
                </table>
   
              <p>Already have an account? <a href="login.php">Sign in</a>.</p>
        
          </form>
		  </center>


</div>
</div>
</div>
</div>
<style type="text/css">
	.center {
  margin-left: auto;
  margin-right: auto;
}
</style>

          <?php
include('footer.php');
?>
   
<?php 
include('connection.php');
if(isset($_POST['SUBMIT']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobno'];
$gender=$_POST['gender'];

$address=$_POST['address'];
$loc=$_POST['loc'];
$transaction_id=$_POST['transaction_id'];
$password=$_POST['pass'];
$cpassword=$_POST['pass1'];
#$upl_cert=$_POST['certificate'];
$target_path = "images/";

$target_path = $target_path . basename( $_FILES['certificate']['name']); 
print_r($_FILES);
if(move_uploaded_file($_FILES['certificate']['tmp_name'], $target_path)) {
    echo "The file ".  basename( $_FILES['certificate']['name']). 
    " has been uploaded";
} else{
    echo "There was an error uploading the file, please try again!";
}
$res=mysqli_query($con,"insert into tb_stylists (name,email,phone,gender,address,location,transaction_id,password,conf_password,certificate,t_status)
value ('$name','$email','$mobile','$gender','$address','$loc','$transaction_id','$password','$cpassword','$target_path','pending')");


//mysqli_query($con,"insert into tb_login (username,password,user_type) value ('$email','$password','stylist')");
		header('location:login.php');




}



?>
   

