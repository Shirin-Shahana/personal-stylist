<?php
session_start();
include('connection.php');
if(isset($_POST['sumbit']))
{
    $u=$_POST['email'];
    $p=$_POST['pass'];
  
    $res=mysqli_query($con,"SELECT * FROM tb_login where username='$u' and password='$p'");
	$cc=mysqli_num_rows($res);
    $row=mysqli_fetch_array($res);
    
	
	if($row['user_type']=='admin')
	{
	    $_SESSION['type']=$row['user_type'];
		
        header('Location:pages/admin/dashboard.php');
    }
	elseif($row['user_type']=='customer')
	{
		$_SESSION['type']=$row['user_type'];
		$_SESSION['cid']=$row['uid'];
		#$_SESSION['location']=$row['location'];
		header('location:pages/customer/viewstylist.php');
	}
		
	elseif($row['user_type']=='stylist')
	{
		$res22=mysqli_query($con,"SELECT * FROM tb_stylists where s_id='$row[uid]' and status='rejected' ");
			
			$cc22=mysqli_num_rows($res22);
			
			if($cc22==1)
			{
				 echo " window.location='stylist_reg.php'";
			}
			else
			{
				$_SESSION['type']=$row['user_type'];
				$_SESSION['sid']=$row['uid'];
				
				header('location:pages/stylist/dashboard.php');
			}
	}
	
    else
    {
        echo "LOGIN FAILED";
    }
}


?>