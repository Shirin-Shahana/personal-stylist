<?php
include('connection.php');
if(isset($_POST['SUBMIT']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobno'];
$gender=$_POST['gender'];
$mail=$_POST['email'];
$address=$_POST['address'];
$loc=$_POST['loc'];
$password=$_POST['pass'];
$cpassword=$_POST['pass1'];


$res=mysqli_query($con,"insert into tb_customer (name,email,phno,gender,address,location,password,conf_password)
value ('$name','$email','$mobile','$gender','$address','$loc','$password','$cpassword')");


mysqli_query($con,"insert into tb_login (username,password,user_type) value ('$email','$password','customer')");
		header('location:register.php');




}




?>