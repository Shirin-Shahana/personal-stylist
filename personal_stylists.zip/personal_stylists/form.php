<form action="" method="POST" enctype="multipart/form-data">
	<input type="file" name="f1">
	<input type="submit" name="submit" value="Upload">
</form>

<?php
if(isset($_POST['submit']))
{
	
	move_uploaded_file($_FILES['f1']['tmp_name'],"videos/".$_FILES['f1']['name']);
	$img=$_FILES['f1']['name'];
	//print_r($_FILES);
	
	echo "<script>alert('Successfully Trained')
		window.location='output.php';
		 </script>"; 

}   
	?>