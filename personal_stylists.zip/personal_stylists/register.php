<?php 
include 'header.php'; 
?>


<?php
include('connection.php');
if(isset($_POST['SUBMIT']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobno'];
$gender=$_POST['gender'];
$mail=$_POST['email'];
$address=$_POST['address'];
$loc=$_POST['loc'];
$password=$_POST['pass'];
$cpassword=$_POST['pass1'];


$res=mysqli_query($con,"insert into tb_customer (name,email,phno,gender,address,location,password,conf_password,status)
value ('$name','$email','$mobile','$gender','$address','$loc','$password','$cpassword','cancel')");

$aa=mysqli_insert_id($con);
//echo $aa;

mysqli_query($con,"insert into tb_login (uid,username,password,user_type) value ('$aa','$email','$password','customer')");
		//header('location:register.php');

}




?>

    
    <!--Body Content-->
<br><br><br>
    <div id="page-content">
    	<!--Page Title-->
    	<div class="page section-header text-center">
			<div class="page-title">
        		<div class="wrapper"><h1 class="page-width"><b>Create an Account</b></h1></div>
      		</div>
		</div>
        <!--End Page Title-->
        
        <div class="container">
        	<div class="row">
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 main-col offset-md-3">
                	<div class="mb-4">
                       <form method="post"  id="CustomerLoginForm" accept-charset="UTF-8" class="contact-form">	
                          <div class="row">
	                          <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="FirstName">Name</label>
                                    <input type="text" name="name" placeholder="" id="FirstName" autofocus="">
                                </div>
                               </div>
                              
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="CustomerEmail">Email</label>
                                    <input type="email" name="email" placeholder="" id="CustomerEmail" class="" autocorrect="off" autocapitalize="off" autofocus="" required>
                                </div>
                            </div>
                              
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="CustomerEmail">Gender</label><br>
                                    <input type="radio" name="gender" placeholder="" id="CustomerEmail" class="" autocorrect="off" autocapitalize="off" autofocus=""value="male" checked>male
                                    <input type="radio" name="gender" placeholder="" id="CustomerEmail" class="" autocorrect="off" autocapitalize="off" autofocus=""value="female" checked>female
                                </div>
                            </div>
                            
                             <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="LastName">Mobile Number</label>
                                    <input type="text" name="mobno" placeholder="" id="LastName" value="" pattern="[56789][0-9]{9}" required>
                                </div>
                               </div>
                              
                               <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="FirstName">Address</label>
                                   
					<textarea cols="60" rows="5" name="address" value="" required></textarea>
                                </div>
                               </div>
                              
                               <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="FirstName">Location</label>
                                    <input type="text" name="loc" placeholder="" id="FirstName" autofocus="" value="" required">
                                </div>
                               </div>
                              
                              
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="CustomerPassword">Password</label>
                                    <input type="password" value="" name="pass" placeholder="" id="password1" class="">                        	
                                </div>
                            </div>
                              
                              <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="CustomerPassword">Confirm Password</label>
                                    <input type="password" value="" name="pass1" placeholder="" id="password2" class="">                        	
                                </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="text-center col-12 col-sm-12 col-md-12 col-lg-12">
                                <input type="submit" class="btn mb-3" value="Create" name="SUBMIT">
                            </div>
                         </div>
                     </form>
                    </div>
               	</div>
            </div>
        </div>
        
    </div>
    <!--End Body Content-->

<script>
				window.onload = function () {
					document.getElementById("password1").onchange = validatePassword;
					document.getElementById("password2").onchange = validatePassword;
				}

				function validatePassword() {
					var pass2 = document.getElementById("password2").value;
					var pass1 = document.getElementById("password1").value;
					if (pass1 != pass2)
						document.getElementById("password2").setCustomValidity("Passwords Don't Match");
					else
						document.getElementById("password2").setCustomValidity('');
					//empty string means no validation error
				}
			</script>

    
  <?php include'footer.php'; ?>