<?php
error_reporting(0);
session_start();
?>

<!DOCTYPE html>
<html class="no-js" lang="en">

<!-- belle/index.html   11 Nov 2019 12:16:10 GMT -->
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Personal Stylist</title>
<meta name="description" content="description">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Favicon -->
<link rel="shortcut icon" href="assets/images/favicon.png" />
<!-- Plugins CSS -->
<link rel="stylesheet" href="assets/css/plugins.css">
<!-- Bootstap CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<!-- Main Style CSS -->
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body class="template-index belle template-index-belle">
<!-- <div id="pre-loader">
    <img src="assets/images/loader.gif" alt="Loading..." />
</div> -->
<div class="pageWrapper">
	<!--Search Form Drawer-->
	<div class="search">
        <div class="search__form">
            <form class="search-bar__form" action="#">
                <button class="go-btn search__button" type="submit"><i class="icon anm anm-search-l"></i></button>
                <input class="search__input" type="search" name="q" value="" placeholder="Search entire store..." aria-label="Search" autocomplete="off">
            </form>
            <button type="button" class="search-trigger close-btn"><i class="anm anm-times-l"></i></button>
        </div>
    </div>
    <!--End Search Form Drawer-->
    <!--Top Header-->
    <div class="top-header">
        <div class="container-fluid">
            <div class="row">
            	<div class="col-10 col-sm-8 col-md-5 col-lg-4">
                 <!--    <div class="currency-picker">
                        <span class="selected-currency">USD</span>
                        <ul id="currencies">
                            <li data-currency="INR" class="">INR</li>
                            <li data-currency="GBP" class="">GBP</li>
                            <li data-currency="CAD" class="">CAD</li>
                            <li data-currency="USD" class="selected">USD</li>
                            <li data-currency="AUD" class="">AUD</li>
                            <li data-currency="EUR" class="">EUR</li>
                            <li data-currency="JPY" class="">JPY</li>
                        </ul>
                    </div> -->
                  <!--   <div class="language-dropdown">
                        <span class="language-dd"></span>
                        <ul id="language">
                            <li class=""></li>
                            <li class=""></li>
                       
			 </ul>
                    </div> -->
                  <!--   <p class="phone-no"><i class="anm anm-phone-s"></i></p> -->
                </div>
                
             <!--  <img src="assets/images/logo.svg" alt="Belle Multipurpose Html Template" title="Belle Multipurpose Html Template"> -->
                        
                    </ul>



                </div>
            </div>
        </div>
    </div>
    <!--End Top Header-->
    <!--Header-->
    <div class="header-wrap classicHeader animated d-flex">
    	<div class="container-fluid">        
            <div class="row align-items-center">
            	<!--Desktop Logo-->
                <div class="logo col-md-2 col-lg-2 d-none d-lg-block">
                    <!-- <a href="index.html">
                    	<img src="assets/images/logo.svg" alt="Belle Multipurpose Html Template" title="Belle Multipurpose Html Template" />
                    </a> -->
                </div>
                <!--End Desktop Logo-->
                <div class="col-2 col-sm-3 col-md-3 col-lg-8">
                	<div class="d-block d-lg-none">
                        <button type="button" class="btn--link site-header__menu js-mobile-nav-toggle mobile-nav--open">
                        	<i class="icon anm anm-times-l"></i>
                            <i class="anm anm-bars-r"></i>
                        </button>
                    </div>
                	<!--Desktop Menu-->
                	<nav class="grid__item" id="AccessibleNav"><!-- for mobile -->
                        <ul id="siteNav" class="site-nav medium center hidearrow">
                            
							
							<?php
							
							if($_SESSION['type']=="admin")
							{
							?>
							 <li class="lvl1 parent megamenu"><a href="dashboard.php">Home <i class="anm anm-angle-down-l"></i></a>  </li>
								<li class="lvl1 parent megamenu"><a href="stylist_view.php">stylist<i class="anm anm-plus-l"></i></a>         </li>
							<li class="lvl1 parent megamenu"><a href="customer_view.php">Customer<i class="anm anm-plus-l"></i></a>         </li>
								        
							    <li class="lvl1 parent megamenu"><a href="viewpackage.php"> package<i class="anm anm-plus-l"></i></a>         </li>
								<li class="lvl1 parent megamenu"><a href="viewwork.php"> works<i class="anm anm-plus-l"></i></a>         </li>
								
								<li class="lvl1 parent megamenu"><a href="viewbooking.php">Booking<i class="anm anm-plus-l"></i></a> 
								
								<li class="lvl1 parent megamenu"><a href="viewpayment.php">Payment<i class="anm anm-plus-l"></i></a> 
								
								<li class="lvl1 parent megamenu"><a href="viewfeedbacks.php">Feedback<i class="anm anm-plus-l"></i></a> </li>
								<li class="lvl1 parent megamenu"><a href="../../logout.php"> Logout<i class="anm anm-plus-l"></i></a>         </li>
							
							
							<?php
							
							}
							elseif($_SESSION['type']=="customer")
							{
							?>
								
								<!--	<li class="lvl1 parent megamenu"><a href="dashboard.php">Home <i class="anm anm-angle-down-l"></i></a>  </li>
								       </li>
							
								
							   
								
							<li class="lvl1 parent megamenu"><a href="viewstylist.php"> Stylist<i class="anm anm-plus-l"></i></a>
					      </li>-->
								
								
								<!-- <li class="lvl1 parent megamenu"><a href="cusviewpackage.php"> package<i class="anm anm-plus-l"></i></a>         </li>  
								<li class="lvl1 parent megamenu"><a href="viewwork.php"> works<i class="anm anm-plus-l"></i></a>         </li>-->
								<li class="lvl1 parent megamenu"><a href="profile.php"> profile<i class="anm anm-plus-l"></i></a>  
								<li class="lvl1 parent megamenu"><a href="viewbooking.php"> Booking<i class="anm anm-plus-l"></i></a>         </li>
								
								
								
								<li class="lvl1 parent megamenu"><a href="../../logout.php"> Logout    <i class="anm anm-plus-l"></i></a>    </li>
							
							
							<?php
							}
							elseif($_SESSION['type']=="stylist")
							{
							?>
							<li class="lvl1 parent megamenu"><a href="dashboard.php">Home <i class="anm anm-angle-down-l"></i></a>  </li>
								<li class="lvl1 parent megamenu"><a href="package.php"> package<i class="anm anm-plus-l"></i></a></li>
								<li class="lvl1 parent megamenu"><a href="viewpackage.php"> View Package<i class="anm anm-plus-l"></i></a></li>
								
								<li class="lvl1 parent megamenu"><a href="viewbooking.php">Booking<i class="anm anm-plus-l"></i></a></li>
								
								
								<li class="lvl1 parent megamenu"><a href="viewpayment.php"> Payment<i class="anm anm-plus-l"></i></a></li>
								
								<li class="lvl1 parent megamenu"><a href="works.php"> works<i class="anm anm-plus-l"></i></a></li>
								
								<li class="lvl1 parent megamenu"><a href="viewfeedbacks.php"> Feedback<i class="anm anm-plus-l"></i></a></li>
								
								<li class="lvl1 parent megamenu"><a href="../../logout.php"> Logout<i class="anm anm-plus-l"></i></a></li>
							
							
							<?php
							}
							else{
							?>
							
							
							
							
                            <li class="lvl1 parent megamenu"><a href="index.php">Home<i class="anm anm-angle-down-l"></i></a>  </li>

							<li class="lvl1 parent megamenu"><a href="stylist_reg.php">Stylist registration<i class="anm anm-angle-down-l"></i></a>  </li>
							<li class="lvl1 parent megamenu"><a href="register.php"> customer registration<i class="anm anm-plus-l"></i></a>         </li>
							<li class="lvl1 parent megamenu"><a href="login.php"> login<i class="anm anm-plus-l"></i></a>         </li>
							
							<?php
							}
							?>
                            
                        <li class="lvl1"><a href=""><b></b> <i class="anm anm-angle-down-l"></i></a></li>
                      </ul>
                    </nav>
                    <!--End Desktop Menu-->
                </div> 
                <!--Mobile Logo-->
                <div class="col-6 col-sm-6 col-md-6 col-lg-2 d-block d-lg-none mobile-logo">
                <!-- 	<div class="logo">
                        <a href="index.html">
                            <img src="assets/images/logo.svg" alt="Belle Multipurpose Html Template" title="Belle Multipurpose Html Template" />
                        </a>
                    </div> -->
                </div>
                <!--Mobile Logo-->
                <div class="col-4 col-sm-3 col-md-3 col-lg-2">
                	<div class="site-cart">
                    <!-- 	<a href="#;" class="site-header__cart" title="Cart">
                        	<i class="icon anm anm-bag-l"></i>
                            <span id="CartCount" class="site-header__cart-count" data-cart-render="item_count">2</span>
                        </a> -->
                        <!--Minicart Popup-->
                        <div id="header-cart" class="block block-cart">
                        	
                           
                        </div>
                        <!--EndMinicart Popup-->
                    </div>
                    <div class="site-header__search">
                    	<!--<button type="button" class="search-trigger"><i class="icon anm anm-search-l"></i></button>-->
                    </div>
                </div>
        	</div>
        </div>
    </div>
    <!--End Header-->
    <!--Mobile Menu-->
    <div class="mobile-nav-wrapper" role="navigation">
		<div class="closemobileMenu"><i class="icon anm anm-times-l pull-right"></i> Close Menu</div>
        <ul id="MobileNav" class="mobile-nav">
        	<li class="lvl1 parent megamenu"><a href="index.php">Home <i class="anm anm-plus-l"></i></a>         </li>
			<li class="lvl1 parent megamenu"><a href="stylist_reg.php">Stylist Register <i class="anm anm-plus-l"></i></a>         </li>
        	<li class="lvl1 parent megamenu"><a href="login.php">Login <i class="anm anm-plus-l"></i></a>         </li>
			<li class="lvl1 parent megamenu"><a href="register.php">customer Register <i class="anm anm-plus-l"></i></a>         </li>
        	
        	<li class="lvl1"><a href="#"><b>Buy Now!</b></a>
        </li>
      </ul>
	</div>
	<!--End Mobile Menu-->
    